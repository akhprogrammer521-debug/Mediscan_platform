"use client";

import { createContext, useContext, useEffect, useState } from "react";
import { notificationsApi } from "@/lib/api";
import { getSocket } from "@/lib/socket";

interface NotificationsContextType {
  unreadCount: number;
  setUnreadCount: React.Dispatch<React.SetStateAction<number>>;
}

const NotificationsContext = createContext<NotificationsContextType | null>(null);

export function NotificationsProvider({ children }: { children: React.ReactNode }) {
  const [unreadCount, setUnreadCount] = useState(0);

  // ✅ 1) تحميل العدد عند فتح التطبيق
  useEffect(() => {
    const load = async () => {
      const res = await notificationsApi.unreadCount();
      if (res.success && typeof res.data === "number") {
        setUnreadCount(res.data);
      }
    };
    load();
  }, []);

  // ✅ 2) Realtime: عند وصول إشعار جديد زِد الرقم
  useEffect(() => {
    const s = getSocket();

    const onNew = () => {
      // إذا الإشعار غير مقروء افتراضيًا (isRead=false) -> زِد
      setUnreadCount((prev) => prev + 1);
    };

    s.on("notification:new", onNew);

    return () => {
      s.off("notification:new", onNew);
    };
  }, []);

  return (
    <NotificationsContext.Provider value={{ unreadCount, setUnreadCount }}>
      {children}
    </NotificationsContext.Provider>
  );
}

export function useNotifications() {
  const ctx = useContext(NotificationsContext);
  if (!ctx) throw new Error("useNotifications must be used inside provider");
  return ctx;
}
