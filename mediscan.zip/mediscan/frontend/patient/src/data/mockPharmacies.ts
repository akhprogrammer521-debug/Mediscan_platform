import type { Pharmacy } from "@/types/pharmacy";

export const MOCK_PHARMACIES: Pharmacy[] = [
  {
    id: "ph1",
    name: "صيدلية الشفاء",
    address: "دمشق – مساكن برزة",
    lat: 33.5431,
    lng: 36.292,
    distanceKm: 2.5,
    isOpen: true,
    phone: "+963999999999",
    openingHours: "8:00 صباحاً – 12:00 ليلاً",
    services: ["قياس ضغط", "خدمة التوصيل", "تحضير وصفات"],
    drugs: [
      {
        id: "panadol500",
        name: "Panadol",
        strength: "500mg",
        form: "Tablet",
        price: 3500,
        available: true,
      },
      {
        id: "augmentin1g",
        name: "Augmentin",
        strength: "1g",
        form: "Tablet",
        price: 8200,
        available: false,
      },
    ],
  },

  {
    id: "ph2",
    name: "صيدلية الرحمة",
    address: "دمشق – أبو رمانة",
    lat: 33.5172,
    lng: 36.2931,
      distanceKm: 4.1,
    isOpen: false,
    phone: "+963988888888",
    openingHours: "10:00 صباحاً – 10:00 مساءً",
    services: ["استشارات دوائية", "جرعات إبر"],
    drugs: [
      {
        id: "brufen400",
        name: "Brufen",
        strength: "400mg",
        form: "Tablet",
        price: 4500,
        available: true,
      },
    ],
  },
];
