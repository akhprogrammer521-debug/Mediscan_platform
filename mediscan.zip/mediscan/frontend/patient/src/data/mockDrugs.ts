import type { DrugInfo } from "@/types/drug";

export const MOCK_DRUGS: DrugInfo[] = [
  {
    id: "1",
    name: "Paracetamol",
    activeIngredient: "Paracetamol",
    indications: "تسكين الألم و خفض الحرارة",
    contraindications: "قصور كبدي شديد",
    dosage: "500mg كل 6 ساعات",
    warnings: "تجنّب تجاوز الجرعة اليومية",
    sideEffects: "غثيان، صداع، طفح جلدي",
    interactions: "يتداخل مع الوارفارين والكحول",
    overdose: "فشل كبدي خطير"
  },
  {
    id: "2",
    name: "Brufen",
    activeIngredient: "Ibuprofen",
    indications: "مضاد التهاب ومسكن ألم",
    contraindications: "قرحة معدية نشطة",
    dosage: "400mg كل 8 ساعات",
    warnings: "تجنّب استخدامه لمرضى الكلى",
    sideEffects: "اضطرابات معدية، دوخة",
    interactions: "يتداخل مع الأسبرين والكورتيزون",
    overdose: "نزيف معدة وفشل كلوي"
  }
];
