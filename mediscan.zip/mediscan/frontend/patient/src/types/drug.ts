export interface DrugInfo {
  id: string;
  name: string;
  activeIngredient: string;
  indications: string;
  contraindications: string;
  dosage: string;
  warnings: string;
  sideEffects: string;
  interactions: string;
  overdose: string;
}
