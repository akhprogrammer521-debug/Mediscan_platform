export interface PharmacyDrug {
  id: string;
  name: string;
  strength: string;
  form?: string;
  price?: number;
  available?: boolean;
}

export interface Pharmacy {
  id: string;
  name: string;
  address: string;
  lat: number;
  lng: number;

  /** المسافة بالكيلومتر */
  distanceKm?: number;

  /** هل الصيدلية مفتوحة الآن */
  isOpen?: boolean;

  /** ساعات العمل */
  openingHours?: string;

  /** رقم الهاتف */
  phone?: string;

  /** خدمات إضافية */
  services: string[];

  /** الأدوية المتوفرة */
  drugs: PharmacyDrug[];
}
