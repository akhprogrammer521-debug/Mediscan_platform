export function timeAgo(dateInput: string | Date): string {
  const date = typeof dateInput === "string"
    ? new Date(dateInput)
    : dateInput;

  const seconds = Math.floor((Date.now() - date.getTime()) / 1000);

  if (seconds < 60) return "الآن";
  if (seconds < 3600) return `منذ ${Math.floor(seconds / 60)} دقيقة`;
  if (seconds < 86400) return `منذ ${Math.floor(seconds / 3600)} ساعة`;
  if (seconds < 2592000) return `منذ ${Math.floor(seconds / 86400)} يوم`;
  if (seconds < 31536000) return `منذ ${Math.floor(seconds / 2592000)} شهر`;

  return `منذ ${Math.floor(seconds / 31536000)} سنة`;
}
