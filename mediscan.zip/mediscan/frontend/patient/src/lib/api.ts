// src/lib/api.ts
import Cookies from "js-cookie";

/* =========================
   CONFIG
========================= */
const API_BASE_URL =
  process.env.NEXT_PUBLIC_API_URL || "http://localhost:5000";

/* =========================
   SHARED TYPES
========================= */
export type Json = string | number | boolean | null | JsonObject | Json[];
export type JsonObject = { [key: string]: Json };

type RequestBody = JsonObject | FormData;

export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
}

export type MedicationStatus = "ACTIVE" | "PAUSED" | "STOPPED";

export type OrderStatus =
  | "PENDING"
  | "ACCEPTED"
  | "REJECTED"
  | "COMPLETED"
  | "CANCELLED";

export type NotificationType = "SYSTEM" | "ORDER";

/* =========================
   AUTH TYPES
========================= */
export interface LoginResponse {
  token: string;
  patient: {
    id: number;
    firstName: string;
    lastName: string;
  };
}

/* =========================
   ENTITY TYPES
========================= */
export interface PatientProfile {
  patient: {
    id: number;
    firstName: string;
    lastName: string;
    phone: string;
    createdAt: string;
    medicalInfo?: MedicalInfo | null;
  };
  user: {
    id: number;
    username: string;
    email: string;
    isActive: boolean;
    createdAt: string;
  };
}

export interface MedicalInfo {
  gender: "MALE" | "FEMALE";
  birthDate: string;
  height: number;
  weight: number;
  currentMedications?: string | null;
  chronicMedications?: string | null;
  chronicDiseases?: string | null;
  allergies?: string | null;
}

export interface MedicationSchedule {
  id: number;
  time: string;
  days: string; 
  logs?: {
    date: string;
    takenAt: string;
  }[];
}


export interface PatientMedication {
  id: number;
  name: string;
  dosage: string;
  reason?: string | null;
  notes?: string | null;
  status: MedicationStatus;
  schedules: MedicationSchedule[];
  createdAt: string;
}

export type WeekDay =
  | "MON"
  | "TUE"
  | "WED"
  | "THU"
  | "FRI"
  | "SAT"
  | "SUN";


export interface Order {
  id: number;
  drugName: string;
  quantity: number;
  status: OrderStatus;
  createdAt: string;
  pharmacy: {
    id: number;
    name: string;
    address: string;
    phone: string;
    latitude?: number | null;
    longitude?: number | null;
  };
  drug: {
    id: number;
    name: string;
    strength: string;
  };
  prescriptionImage?: string | null;
}

export interface DrugInfo {
  id: number;
  name: string;
  strength: string;
  description?: string | null;
  composition: string;
  indications: string;
  contraindications: string;
  dosage: string;
  warnings: string;
  sideEffects: string;
  interactions: string;
  overdose: string;
}

export interface OcrAnalysis {
  drugName?: string;
  language?: string;
  confidence?: number;
}



export interface OcrScanResponse {
  scan: {
    id: number;
    imageUrl: string;
    text: string;
    language: string;
    createdAt: string;
  };
  text: string;
  analysis?: OcrAnalysis;
  drug?: DrugInfo | null;
  ttsText?: string | null;
}

export interface PrescriptionScanResponse {
  prescription: {
    id: number;
    imageUrl: string;
    content: string;
    translatedContent?: string | null;
    createdAt: string;
  };
  text: string;
  translated?: string | null;
  drugs: DrugInfo[];
  ttsText?: string | null;
}

export interface PatientDashboard {
  stats: {
    activeMedications: number;
    currentOrders: number;
    todayDoses: number;
    notificationsCount: number;
  };
  notifications: {
    id: number;
    title: string;
    message: string;
  }[];
}

/* =========================
   DRUG & PHARMACY TYPES
========================= */
export interface PublicDrug {
  id: number;
  name: string;
  strength: string;
  description?: string | null;
}

export interface Pharmacy {
  id: number;
  name: string;
  address: string;
  phone: string;
  latitude?: number | null;
  longitude?: number | null;
}

export interface PharmacyStockItem {
  id: number;
  quantity: number;

  drug?: {
    id: number;
    name: string;
    strength: string;
  } | null;

  customDrug?: {
    id: number;
    name: string;
    strength?: string | null;
  } | null;
}


/* =========================
   SEARCH RESULT TYPES
========================= */
export interface PharmacyStockByDrugItem {
  pharmacy: Pharmacy;
  quantity: number;
}

export interface PharmacyStockByPharmacyItem {
  drug: PublicDrug;
  quantity: number;
}

/* =========================
   ORDER TYPE (FINAL)
========================= */
export interface Order {
  id: number;
  drugName: string;
  quantity: number;
  status: OrderStatus;
  createdAt: string;

  pharmacy: Pharmacy;

  drug: {
    id: number;
    name: string;
    strength: string;
  };

  prescriptionImage?: string | null;
}



export interface PatientNotification {
  id: number;
  type: NotificationType;
  title: string;
  message: string;
  isRead: boolean;
  createdAt: string;
}

/* =========================
   API CLIENT
========================= */
class ApiClient {
  constructor(private baseUrl: string) {}

  private async request<T>(
    endpoint: string,
    options: Omit<RequestInit, "body"> & { body?: RequestBody } = {}
  ): Promise<ApiResponse<T>> {
    const token = Cookies.get("token");

    const headers: Record<string, string> = {
      ...(options.headers as Record<string, string>),
    };

    if (options.body && !(options.body instanceof FormData)) {
      headers["Content-Type"] = "application/json";
    }

    if (token) {
      headers.Authorization = `Bearer ${token}`;
    }

    const body =
      options.body instanceof FormData
        ? options.body
        : options.body
        ? JSON.stringify(options.body)
        : undefined;

    try {
      const res = await fetch(`${this.baseUrl}${endpoint}`, {
        ...options,
        headers,
        body,
      });

      if (res.status === 204) return { success: true };

      const data = await res.json();
      return data as ApiResponse<T>;
    } catch (e) {
      const message = e instanceof Error ? e.message : "Network error";
      return { success: false, error: message };
    }
  }

  get<T>(endpoint: string) {
    return this.request<T>(endpoint, { method: "GET" });
  }

  post<T>(endpoint: string, body?: RequestBody) {
    return this.request<T>(endpoint, { method: "POST", body });
  }

  put<T>(endpoint: string, body?: RequestBody) {
    return this.request<T>(endpoint, { method: "PUT", body });
  }

  delete<T>(endpoint: string) {
    return this.request<T>(endpoint, { method: "DELETE" });
  }
}

/* =========================
   CLIENT INSTANCE
========================= */
const patientApi = new ApiClient(`${API_BASE_URL}/api/patient`);
const pharmaciesApiClient = new ApiClient(`${API_BASE_URL}/api/pharmacy`);
const drugsApiClient = new ApiClient(`${API_BASE_URL}/api/drugs`);


/* =========================
   AUTH
========================= */
export const authApi = {
  register: (payload: JsonObject) =>
    patientApi.post<{ token: string }>("/register", payload),

  login: (payload: JsonObject) =>
    patientApi.post<LoginResponse>("/login", payload),
};

/* =========================
   MEDICAL INFO (STEP 2)
========================= */
export const medicalInfoApi = {
  submit: (payload: MedicalInfo) =>
    patientApi.post("/medical-info", payload as unknown as JsonObject),
};

/* =========================
   DASHBOARD
========================= */
export const dashboardApi = {
  get: () => patientApi.get<PatientDashboard>("/dashboard"),
};

/* =========================
   PROFILE
========================= */
export const profileApi = {
  get: () => patientApi.get<PatientProfile>("/profile"),
  update: (payload: JsonObject) =>
    patientApi.put<PatientProfile>("/profile", payload),

    
  };

/* =========================
   PASSWORD
========================= */
export const passwordApi = {
  change: (payload: {
    currentPassword: string;
    newPassword: string;
  }) =>
    patientApi.post("/change-password", payload),
};


/* =========================
   MEDICATIONS
========================= */
export const medicationsApi = {
  getAll: () => patientApi.get<PatientMedication[]>("/medications"),

  getOne: (id: number) =>
    patientApi.get<PatientMedication>(`/medications/${id}`),

  create: (payload: {
  name: string;
  dosage: string;
  notes?: string;
  schedules: {
    time: string;
    days: WeekDay[];
  }[];
}) =>
  patientApi.post<PatientMedication>("/medications", payload),


  update: (
    id: number,
    payload: {
      name?: string;
      dosage?: string;
      notes?: string;
      schedules?: {
  time: string;
  days: WeekDay[];
}[];

      status?: "ACTIVE" | "PAUSED" | "STOPPED";
    }
  ) =>
    patientApi.put<PatientMedication>(`/medications/${id}`, payload),

  delete: (id: number) =>
    patientApi.delete(`/medications/${id}`),

  markDoseTaken: (scheduleId: number) =>
    patientApi.post(`/medication-logs/schedules/${scheduleId}/taken`),
};

/* =========================
   MEDICATION EXTRA
========================= */
export const medicationExtraApi = {
  pause: (id: number) =>
    patientApi.put(`/medications/${id}/pause`),

  resume: (id: number) =>
    patientApi.put(`/medications/${id}/resume`),

  adherence: () =>
    patientApi.get<{
      totalDoses: number;
      takenDoses: number;
      adherenceRate: number;
    }>("/medications/adherence"),
};


/* =========================
   MEDICATION LOG
========================= */
export const medicationLogApi = {
  markTaken: (scheduleId: number) =>
    patientApi.post(`/medication-logs/schedules/${scheduleId}/taken`),
};

/* =========================
   ORDERS
========================= */
export const ordersApi = {
  getMy: () => patientApi.get<Order[]>("/orders/my"),

  create: (payload: JsonObject) =>
    patientApi.post<Order>("/orders", payload),

  cancel: (orderId: number) =>
    patientApi.delete(`/orders/${orderId}`),
};

export const publicDrugsApi = {
  getAll: () => drugsApiClient.get<PublicDrug[]>("/"),
  getOne: (id: number) => drugsApiClient.get<PublicDrug>(`/${id}`),
};

export const pharmaciesApi = {
  getAll: () => pharmaciesApiClient.get<Pharmacy[]>("/"),
  getOne: (id: number) => pharmaciesApiClient.get<Pharmacy>(`/${id}`),
};

export const patientSearchApi = {
  pharmaciesByDrug: (drugId: number) =>
    patientApi.get<PharmacyStockByDrugItem[]>(
      `/search/drugs/${drugId}/pharmacies`
    ),

  drugsByPharmacy: (pharmacyId: number) =>
    patientApi.get<PharmacyStockItem[]>(
      `/search/pharmacies/${pharmacyId}/drugs`
    ),
};

/* =========================
   OCR
========================= */
export const ocrApi = {
  scanDrug: (file: File) => {
    const fd = new FormData();
    fd.append("image", file);
    return patientApi.post<OcrScanResponse>("/ocr/scan", fd);
  },

  scanPrescription: (file: File) => {
    const fd = new FormData();
    fd.append("image", file);
    return patientApi.post<PrescriptionScanResponse>(
      "/ocr/scan-prescription",
      fd
    );
  },
  getScanResult: (scanId: number) => {
    return patientApi.get<OcrScanResponse>(`/ocr/scans/${scanId}`);
  },
};


/* =========================
   TTS (PATIENT)
========================= */
export const ttsApi = {
  speak: (text: string, language: "ar" | "en" = "ar") =>
    patientApi.post<{ audioUrl: string }>("/tts/speak", {
      text,
      language,
    }),
};

/* =========================
   AI ASSISTANT (PATIENT)
========================= */

export type PatientAIChatResponse = {
  answer: string
}

export const patientAiApi = {
  chat(message: string, language: "ar" | "en" = "ar") {
    return patientApi.post<PatientAIChatResponse>(
      "/ai/chat",
      { message, language }
    )
  },
}


/* =========================
   NOTIFICATIONS
========================= */
export const notificationsApi = {
  getAll: () =>
    patientApi.get<PatientNotification[]>("/notifications"),

  markAsRead: (id: number) =>
    patientApi.put(`/notifications/${id}/read`),
  markAllAsRead: () =>
    patientApi.put("/notifications/read-all"),
   unreadCount: () =>
    patientApi.get<number>("/notifications/unread-count"),
};


/* =========================
   ACCOUNT
========================= */
export const accountApi = {
  delete: () => patientApi.delete("/account"),
};



export interface SystemSetting {
  key: string;
  value: string;
}

export const settingsApi = {
  get: () =>
    patientApi.get<SystemSetting[]>("/settings"),

  update: (settings: SystemSetting[]) =>
    patientApi.put("/settings", {
      settings: settings.map((s) => ({
        key: s.key,
        value: s.value,
      })),
    }),
};

