import { io, Socket } from "socket.io-client";
import Cookies from "js-cookie";

let socket: Socket | null = null;

export function getSocket(userId?: number) {
  if (socket) return socket;

  const token = Cookies.get("token");

  socket = io(
    process.env.NEXT_PUBLIC_API_URL || "http://localhost:5000",
    {
      auth: { token },
      transports: ["websocket"],
    }
  );

  socket.on("connect", () => {
    if (userId) {
      socket?.emit("join", userId);
    }
  });

  return socket;
}

export function disconnectSocket() {
  socket?.disconnect();
  socket = null;
}
