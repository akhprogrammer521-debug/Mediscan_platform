export default function Toast({ message }: { message: string }) {
  return (
    <div className="
      fixed bottom-20 left-1/2 -translate-x-1/2
      bg-slate-800 text-white px-4 py-2 rounded-xl shadow-soft
      animate-bounce
    ">
      {message}
    </div>
  );
}
