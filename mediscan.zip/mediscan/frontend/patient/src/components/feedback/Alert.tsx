interface Props {
  type?: "success" | "error" | "info";
  message: string;
}

export default function Alert({ type = "info", message }: Props) {
  const colors = {
    success: "bg-emerald-100 text-emerald-700",
    error: "bg-red-100 text-red-700",
    info: "bg-blue-100 text-blue-700",
  };

  return (
    <div className={`p-3 rounded-xl text-sm ${colors[type]}`}>
      {message}
    </div>
  );
}
