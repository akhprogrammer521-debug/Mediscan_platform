interface Props {
  message: string;
}

export default function EmptyState({ message }: Props) {
  return (
    <div className="text-center py-10 text-slate-500 dark:text-slate-400">
      <p>{message}</p>
    </div>
  );
}
