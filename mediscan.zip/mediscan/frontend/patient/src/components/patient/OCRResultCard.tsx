interface OCRResultCardProps {
  title: string;
  value: string;
}

export default function OCRResultCard({ title, value }: OCRResultCardProps) {
  return (
    <div className="bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl p-3 shadow-soft">
      <p className="text-sm font-semibold">{title}</p>
      <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">{value}</p>
    </div>
  );
}
