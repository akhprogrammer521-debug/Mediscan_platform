interface PrescriptionCardProps {
  doctor: string;
  medicines: string[];
  date: string;
}

export default function PrescriptionCard({
  doctor,
  medicines,
  date,
}: PrescriptionCardProps) {
  return (
    <div className="bg-white dark:bg-slate-800 border rounded-2xl p-4 shadow-soft">
      <h3 className="font-semibold">وصفة طبية</h3>

      <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
        الطبيب: {doctor}
      </p>

      <p className="font-semibold mt-3">الأدوية:</p>
      <ul className="list-disc pr-5 text-sm">
        {medicines.map((m, i) => (
          <li key={i}>{m}</li>
        ))}
      </ul>

      <p className="text-xs text-slate-500 mt-3">{date}</p>
    </div>
  );
}
