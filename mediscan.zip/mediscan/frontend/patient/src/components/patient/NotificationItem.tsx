interface NotificationItemProps {
  title: string;
  message: string;
  date: string;
}

export default function NotificationItem({
  title,
  message,
  date,
}: NotificationItemProps) {
  return (
    <div className="bg-white dark:bg-slate-800 border rounded-xl shadow-soft p-3">
      <h4 className="font-semibold">{title}</h4>
      <p className="text-sm text-slate-600 dark:text-slate-400">{message}</p>
      <p className="text-xs text-slate-400 mt-1">{date}</p>
    </div>
  );
}
