interface PharmacyCardProps {
  name: string;
  distance: string;
  onClick?: () => void;
}

export default function PharmacyCard({
  name,
  distance,
  onClick,
}: PharmacyCardProps) {
  return (
    <div
      onClick={onClick}
      className="
        bg-white dark:bg-slate-800 rounded-2xl 
        border border-slate-200 dark:border-slate-700 
        shadow-soft p-4 cursor-pointer
      "
    >
      <h3 className="font-semibold">{name}</h3>
      <p className="text-sm text-slate-600 dark:text-slate-400">
        يبعد: {distance}
      </p>
    </div>
  );
}
