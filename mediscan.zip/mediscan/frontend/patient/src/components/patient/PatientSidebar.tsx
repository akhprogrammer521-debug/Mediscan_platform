"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import Image from "next/image";
import {
  Home,
  User,
  Pill,
  FileText,
  MapPin,
  LogOut,
  Menu,
  Scan,
  Bot,
  Settings,
} from "lucide-react";
import Drawer from "@/components/ui/drawer";
import { useState } from "react";
import Button from "../ui/button";

export default function PatientSidebar() {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);

  const links = [
    { name: "الرئيسية", href: "/dashboard", icon: Home },
    { name: "ملفي الشخصي", href: "/profile", icon: User },
    { name: "الأدوية الخاصة بي", href: "/my-medicines", icon: Pill },
    { name: "طلباتي", href: "/orders", icon: FileText },
    { name: "الصيدليات", href: "/pharmacies", icon: MapPin },
    { name: "مسح دواء", href: "/scan", icon: Scan },
    { name: "مساعد آلي", href: "/chatbot", icon: Bot },
    // { name: "الإعدادات", href: "/settings", icon: Settings },
  ];

  const activeClass =
    "bg-primary-50 text-primary-700 dark:bg-primary-900/40 dark:text-primary-300 border-primary-300 dark:border-primary-700";

  const normalClass =
    "text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800";
  const handleNext = () => {
    // لاحقاً يربط مع الـ API
    window.location.href = "/auth/login";
  };

  return (
    <>
      {/* Mobile Menu Button */}
      <Button
        className="md:hidden fixed top-4 right-4 z-50 bg-white dark:bg-slate-900 shadow px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700"
        onClick={() => setOpen(true)}
      >
        <Menu size={24} />
      </Button>

      {/* Desktop Sidebar */}
      <aside
        dir="rtl"
        className="
          hidden md:flex flex-col
          w-64 h-screen p-5
          border-l border-slate-200 dark:border-slate-800
          bg-white dark:bg-slate-900
          fixed right-0 top-0
        "
      >
        {/* Logo */}
        <div className="flex items-center gap-2 mb-8">
          <Image src="/logo.png" alt="MediScan Logo" width={32} height={32} />
          <span className="font-bold text-lg text-slate-800 dark:text-slate-100">
            MediScan
          </span>
        </div>

        {/* Links */}
        <nav className="flex flex-col gap-2">
          {links.map((item) => {
            const Icon = item.icon;
            const isActive = pathname === item.href;

            return (
              <Link
                key={item.href}
                href={item.href}
                className={`
                  flex items-center gap-3 p-3 rounded-xl border
                  transition
                  ${isActive ? activeClass : normalClass}
                `}
              >
                <Icon size={20} />
                {item.name}
              </Link>
            );
          })}
        </nav>

        {/* Logout */}

        <button
          onClick={handleNext}

          className="mt-auto flex items-center gap-3 p-3 rounded-xl border border-red-300 text-red-600
                     hover:bg-red-50 dark:hover:bg-red-900/20 transition"
        >
          <LogOut size={20} />
          تسجيل الخروج
        </button>
      </aside>


      {/* Mobile Drawer Sidebar */}
      <Drawer open={open} onClose={() => setOpen(false)}>
        <div
          dir="rtl"
          className="w-64 h-full bg-white dark:bg-slate-900 p-5 flex flex-col"
        >
          <div className="flex items-center gap-2 mb-8">
            <Image src="/logo.png" alt="MediScan Logo" width={32} height={32} />
            <span className="font-bold text-lg text-slate-800 dark:text-slate-100">
              mediScan
            </span>
          </div>

          <nav className="flex flex-col gap-2">
            {links.map((item) => {
              const Icon = item.icon;
              const isActive = pathname === item.href;

              return (
                <Link
                  key={item.href}
                  href={item.href}
                  onClick={() => setOpen(false)}
                  className={`
                    flex items-center gap-3 p-3 rounded-xl border
                    transition
                    ${isActive ? activeClass : normalClass}
                  `}
                >
                  <Icon size={20} />
                  {item.name}
                </Link>
              );
            })}
          </nav>

          <button
            className="mt-auto flex items-center gap-3 p-3 rounded-xl border border-red-300 text-red-600
                       hover:bg-red-50 dark:hover:bg-red-900/20 transition"
          >
            <LogOut size={20} />
            تسجيل الخروج
          </button>
        </div>
      </Drawer>
    </>
  );
}

