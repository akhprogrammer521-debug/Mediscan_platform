interface OrderCardProps {
  medicine: string;
  status: string;
  date: string;
}

export default function OrderCard({
  medicine,
  status,
  date,
}: OrderCardProps) {
  const statusColor =
    status === "قيد التنفيذ"
      ? "text-primary-600"
      : status === "مكتمل"
      ? "text-emerald-600"
      : "text-red-500";

  return (
    <div className="bg-white dark:bg-slate-800 border shadow-soft rounded-2xl p-4">
      <h3 className="font-semibold">{medicine}</h3>
      <p className={`text-sm mt-1 ${statusColor}`}>{status}</p>
      <p className="text-xs text-slate-500 mt-2">{date}</p>
    </div>
  );
}
