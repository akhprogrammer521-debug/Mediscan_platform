interface Props {
  height?: string;
  weight?: string;
  chronicDiseases?: string[];
  allergies?: string[];
}

export default function MedicalInfoSection({
  height,
  weight,
  chronicDiseases = [],
  allergies = [],
}: Props) {
  return (
    <div className="bg-white dark:bg-slate-800 p-4 rounded-2xl border shadow-soft">
      <h3 className="text-lg font-semibold mb-2">المعلومات الصحية</h3>

      <p className="text-sm text-slate-600 dark:text-slate-400">الطول: {height} سم</p>
      <p className="text-sm text-slate-600 dark:text-slate-400">الوزن: {weight} كغ</p>

      <p className="text-sm font-semibold mt-4">الأمراض المزمنة:</p>

      <ul className="list-disc pr-5">
        {chronicDiseases.length > 0 ? (
          chronicDiseases.map((d, i) => <li key={i}>{d}</li>)
        ) : (
          <li className="text-sm text-slate-500">لا يوجد</li>
        )}
      </ul>

      <p className="text-sm font-semibold mt-4">الحساسية:</p>

      <ul className="list-disc pr-5">
        {allergies.length > 0 ? (
          allergies.map((a, i) => <li key={i}>{a}</li>)
        ) : (
          <li className="text-sm text-slate-500">لا يوجد</li>
        )}
      </ul>

    </div>
  );
}
