interface Props {
  label: string;
  value1: string;
  value2: string;
}

export default function CompareDrugItem({ label, value1, value2 }: Props) {
  return (
    <div className="bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl p-3 mb-2">
      <h4 className="font-semibold mb-1 text-sm">{label}</h4>

      <div className="flex justify-between text-sm">
        <span className="text-primary-600 font-medium">{value1}</span>
        <span className="text-red-500 font-medium">{value2}</span>
      </div>
    </div>
  );
}
