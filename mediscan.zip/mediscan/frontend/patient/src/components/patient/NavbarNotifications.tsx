"use client";

import Link from "next/link";
import { Bell } from "lucide-react";
import { useEffect } from "react";
import { notificationsApi } from "@/lib/api";
import { useNotifications } from "@/context/NotificationsContext";
import { getSocket } from "@/lib/socket";

export default function NavbarNotifications() {
  const { unreadCount, setUnreadCount } = useNotifications();

  useEffect(() => {
    let mounted = true;

    const init = async () => {
      // 1️⃣ جلب العدد الحالي مرة واحدة
      const res = await notificationsApi.unreadCount();
      if (mounted && res.success && typeof res.data === "number") {
        setUnreadCount(res.data);
      }

      // 2️⃣ Socket Realtime
      const userId = Number(localStorage.getItem("userId"));
      if (!userId) return;

      const socket = getSocket(userId);

      socket.on("notification:new", () => {
        setUnreadCount((prev) => prev + 1);
      });
    };

    init();

    return () => {
      mounted = false;
    };
  }, [setUnreadCount]);

  return (
    <Link href="/notifications">
      <div className="relative cursor-pointer">
        <Bell size={22} className="text-slate-700 dark:text-slate-200" />

        {unreadCount > 0 && (
          <span className="absolute -top-2 -right-2 min-w-[18px] h-[18px] bg-red-500 text-white text-[10px] rounded-full flex items-center justify-center">
            {unreadCount}
          </span>
        )}
      </div>
    </Link>
  );
}
