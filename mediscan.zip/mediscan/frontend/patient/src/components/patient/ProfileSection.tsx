interface ProfileSectionProps {
  name: string;
  email: string;
  phone: string;
}

export default function ProfileSection({
  name,
  email,
  phone,
}: ProfileSectionProps) {
  return (
    <div className="bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl p-4 shadow-soft">
      <h3 className="text-lg font-semibold mb-2">البيانات الشخصية</h3>

      <p className="text-sm text-slate-600 dark:text-slate-300">
        <span className="font-medium">الاسم:</span> {name}
      </p>

      <p className="text-sm text-slate-600 dark:text-slate-300 mt-1">
        <span className="font-medium">البريد الإلكتروني:</span> {email}
      </p>

      <p className="text-sm text-slate-600 dark:text-slate-300 mt-1">
        <span className="font-medium">رقم الهاتف:</span> {phone}
      </p>
    </div>
  );
}
