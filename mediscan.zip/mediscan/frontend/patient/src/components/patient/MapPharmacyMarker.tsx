interface Props {
  name: string;
  distance: string;
}

export default function MapPharmacyMarker({ name, distance }: Props) {
  return (
    <div className="bg-white dark:bg-slate-800 p-2 rounded-md border shadow-soft text-center">
      <h4 className="text-sm font-semibold">{name}</h4>
      <p className="text-xs text-slate-500">يبعد: {distance}</p>
    </div>
  );
}
