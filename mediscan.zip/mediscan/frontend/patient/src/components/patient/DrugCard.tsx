interface DrugCardProps {
  name: string;
  dose: string;
  onClick?: () => void;
}

export default function DrugCard({ name, dose, onClick }: DrugCardProps) {
  return (
    <div
      onClick={onClick}
      className="
        bg-white dark:bg-slate-800 rounded-2xl 
        border border-slate-200 dark:border-slate-700 
        shadow-soft p-4 cursor-pointer
      "
    >
      <h3 className="font-semibold">{name}</h3>
      <p className="text-sm text-slate-500">{dose}</p>
    </div>
  );
}
