"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

export default function BottomNav() {
  const path = usePathname();

  const links = [
    { href: "/patient", label: "الرئيسية" },
    { href: "/patient/scan", label: "مسح" },
    { href: "/patient/pharmacies", label: "الصيدليات" },
    { href: "/patient/profile", label: "حسابي" },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white dark:bg-slate-800 border-t border-slate-200 dark:border-slate-700 flex justify-around py-3 z-50">
      {links.map((item) => (
        <Link
          key={item.href}
          href={item.href}
          className={`text-sm ${
            path === item.href
              ? "text-primary-600 font-semibold"
              : "text-slate-500 dark:text-slate-300"
          }`}
        >
          {item.label}
        </Link>
      ))}
    </nav>
  );
}
