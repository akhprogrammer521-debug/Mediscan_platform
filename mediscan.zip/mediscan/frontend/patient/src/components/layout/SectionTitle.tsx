export default function SectionTitle({ title }: { title: string }) {
  return (
    <h2 className="text-lg font-semibold text-slate-700 dark:text-slate-200 my-4">
      {title}
    </h2>
  );
}
