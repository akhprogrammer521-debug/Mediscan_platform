export default function PageContainer({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div className="max-w-xl mx-auto px-4 pb-24 pt-4">{children}</div>
  );
}
