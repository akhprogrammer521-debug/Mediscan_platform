"use client";

export default function Header({ title }: { title: string }) {
  return (
    <header className="w-full py-4 bg-white dark:bg-slate-800 shadow-soft border-b border-slate-200 dark:border-slate-700 px-4">
      <h1 className="text-xl font-semibold">{title}</h1>
    </header>
  );
}
