"use client";

import { useState } from "react";

interface Props {
  label: string;
  value?: string;
  placeholder?: string;
  onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
}

export default function PasswordField({ label, value, onChange, placeholder }: Props) {
  const [show, setShow] = useState(false);

  return (
    <div className="flex flex-col gap-1 my-2">
      <label className="text-sm">{label}</label>

      <div className="relative">
        <input
          type={show ? "text" : "password"}
          value={value}
          onChange={onChange}
          placeholder={placeholder}
          className="
            w-full px-4 py-2 rounded-xl pr-12
            border border-slate-300 dark:border-slate-600
            bg-white dark:bg-slate-800
            focus:outline-none focus:ring-2 focus:ring-primary-600
          "
        />

        <button
          type="button"
          onClick={() => setShow(!show)}
          className="absolute left-3 top-1/2 -translate-y-1/2 text-sm text-slate-500"
        >
          {show ? "إخفاء" : "عرض"}
        </button>
      </div>
    </div>
  );
}
