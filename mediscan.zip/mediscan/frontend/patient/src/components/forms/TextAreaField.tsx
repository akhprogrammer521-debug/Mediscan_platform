import React from "react";

interface Props {
  label: string;
  value?: string;
  type?: string;
  placeholder?: string;
  onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
}

export default function TextField({
  label,
  value,
  type = "text",
  placeholder,
  onChange,
}: Props) {
  return (
    <div className="flex flex-col gap-1 my-2">
      <label className="text-sm text-slate-600 dark:text-slate-300">
        {label}
      </label>

      <input
        type={type}
        value={value}
        onChange={onChange}
        placeholder={placeholder}
        className="
          w-full px-4 py-2 rounded-xl
          border border-slate-300 dark:border-slate-600
          bg-white dark:bg-slate-800
          focus:outline-none focus:ring-2 focus:ring-primary-600
        "
      />
    </div>
  );
}
