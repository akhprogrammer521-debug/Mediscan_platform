// src/components/map/PharmacyCard.tsx
"use client";

import { Phone, Navigation } from "lucide-react";
import Link from "next/link";
import type { Pharmacy } from "@/types/pharmacy";

interface Props {
  pharmacy: Pharmacy;
  showDistance?: boolean;
}

export default function PharmacyCard({ pharmacy, showDistance = true }: Props) {
  const googleMapsUrl = `https://www.google.com/maps/search/?api=1&query=${pharmacy.lat},${pharmacy.lng}`;

  return (
    <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 p-3 text-right space-y-1 w-full max-w-sm">
      <div className="flex items-center justify-between gap-2">
        <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
          {pharmacy.name}
        </h3>
        {pharmacy.isOpen ? (
          <span className="text-[11px] px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-200 border border-emerald-200 dark:border-emerald-700">
            مفتوحة الآن
          </span>
        ) : (
          <span className="text-[11px] px-2 py-0.5 rounded-full bg-slate-50 text-slate-600 dark:bg-slate-800 dark:text-slate-300 border border-slate-200 dark:border-slate-700">
            مغلقة حالياً
          </span>
        )}
      </div>

      <p className="text-[11px] text-slate-600 dark:text-slate-300">
        {pharmacy.address}
      </p>

      <p className="text-[11px] text-slate-500 dark:text-slate-400">
        ساعات العمل: {pharmacy.openingHours}
      </p>

      {showDistance && pharmacy.distanceKm != null && (
        <p className="text-[11px] text-slate-500 dark:text-slate-400">
          المسافة التقريبية:{" "}
          <span className="font-medium text-slate-800 dark:text-slate-100">
            {pharmacy.distanceKm} كم
          </span>
        </p>
      )}

      <div className="flex items-center justify-between gap-2 pt-2">
        <a
          href={`tel:${pharmacy.phone}`}
          className="inline-flex items-center gap-1 text-[11px] px-2.5 py-1 rounded-xl border border-slate-300 dark:border-slate-600 text-slate-700 dark:text-slate-100 hover:bg-slate-50 dark:hover:bg-slate-800 transition"
        >
          <Phone size={14} />
          اتصال
        </a>

        <a
          href={googleMapsUrl}
          target="_blank"
          rel="noreferrer"
          className="inline-flex items-center gap-1 text-[11px] px-2.5 py-1 rounded-xl border border-primary-500 text-primary-600 dark:text-primary-300 hover:bg-primary-50 dark:hover:bg-primary-900/40 transition"
        >
          <Navigation size={14} />
          فتح في خرائط غوغل
        </a>

        <Link
          href={`/pharmacies/${pharmacy.id}`}
          className="inline-flex items-center gap-1 text-[11px] px-2.5 py-1 rounded-xl bg-primary-600 text-white hover:bg-primary-700 transition"
        >
          تفاصيل الصيدلية
        </Link>
      </div>
    </div>
  );
}
