// src/components/map/PharmaciesMap.tsx
"use client";

import { useState } from "react";
import {
  GoogleMap,
  Marker,
  InfoWindow,
  useJsApiLoader,
} from "@react-google-maps/api";
import type { Pharmacy } from "@/types/pharmacy";
import PharmacyCard from "./PharmacyCard";
import { MapPin } from "lucide-react";

interface Props {
  pharmacies: Pharmacy[];
  userLocation?: { lat: number; lng: number };
}

/** مركز افتراضي مثلاً رام الله – غيّره لما تحتاج */
const DEFAULT_CENTER = { lat: 31.9, lng: 35.2 };


const MAP_STYLE: React.CSSProperties = {
  width: "100%",
  height: "420px",
  borderRadius: "1.5rem",
};

export default function PharmaciesMap({ pharmacies , userLocation  }: Props) {
  const [selectedId, setSelectedId] = useState<string | null>(null);

  const { isLoaded, loadError } = useJsApiLoader({
    id: "google-maps-script",
  googleMapsApiKey: process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY ?? "",
  libraries: ["places"],
  language: "en",
  region: "US",
  });

  if (loadError) {
    return (
      <p className="text-sm text-rose-600 dark:text-rose-300">
        تعذر تحميل خريطة غوغل. تأكد من مفتاح API.
      </p>
    );
  }

  if (!isLoaded) {
    return (
      <div className="w-full h-[420px] rounded-3xl border border-slate-200 dark:border-slate-800 flex items-center justify-center bg-slate-50 dark:bg-slate-900">
        <p className="text-sm text-slate-500 dark:text-slate-300">
          جارٍ تحميل الخريطة…
        </p>
      </div>
    );
  }

  const selectedPharmacy =
    selectedId != null
      ? pharmacies.find((p) => p.id === selectedId) ?? null
      : null;

  return (
    <div className="relative w-full">
      <GoogleMap
        mapContainerStyle={MAP_STYLE}
        center={DEFAULT_CENTER}
        zoom={13}
        options={{
          disableDefaultUI: true,
          zoomControl: true,
          fullscreenControl: false,
          mapTypeControl: false,
          streetViewControl: false,
        }}
      >
        {/* العلامة الخاصة بالمستخدم (مركز افتراضي حالياً) */}
        <Marker
          position={userLocation ?? DEFAULT_CENTER}
          icon={{
            path: google.maps.SymbolPath.CIRCLE,
            scale: 6,
            strokeColor: "#2563eb",
            strokeWeight: 2,
            fillColor: "#60a5fa",
            fillOpacity: 1,
          }}
        />

        {/* صيدليات */}
        {pharmacies.map((pharmacy) => (
          <Marker
            key={pharmacy.id}
            position={{ lat: pharmacy.lat, lng: pharmacy.lng }}
            onClick={() => setSelectedId(pharmacy.id)}
            title={pharmacy.name}
            icon={{
              url:
                "https://maps.gstatic.com/mapfiles/ms2/micons/pharmacy.png",
            }}
          />
        ))}

        {/* نافذة المعلومات */}
        {selectedPharmacy && (
          <InfoWindow
            position={{
              lat: selectedPharmacy.lat,
              lng: selectedPharmacy.lng,
            }}
            onCloseClick={() => setSelectedId(null)}
          >
            <div dir="rtl">
              <PharmacyCard pharmacy={selectedPharmacy} showDistance />
            </div>
          </InfoWindow>
        )}
      </GoogleMap>

      {/* وسيلة إيضاح بسيطة */}
      <div className="absolute bottom-3 left-3 rounded-full bg-white/90 dark:bg-slate-900/90 border border-slate-200 dark:border-slate-700 px-3 py-1 flex items-center gap-2 text-[11px] text-slate-700 dark:text-slate-200 shadow-sm">
        <span className="flex items-center gap-1">
          <span className="inline-block w-3 h-3 rounded-full bg-blue-500" />
          موقعك التقريبي
        </span>
        <span className="flex items-center gap-1">
          <MapPin size={13} className="text-emerald-600" />
          صيدلية قريبة
        </span>
      </div>
    </div>
  );
}
