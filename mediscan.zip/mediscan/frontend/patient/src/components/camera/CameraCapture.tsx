"use client";

import { useEffect, useRef, useState } from "react";
import Button from "@/components/ui/button";
import { X } from "lucide-react";

interface Props {
  onCapture: (file: File) => void;
  onClose: () => void;
}

export default function CameraCapture({ onCapture, onClose }: Props) {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const [error, setError] = useState("");

  useEffect(() => {
    let stream: MediaStream;

    async function startCamera() {
      try {
        stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: "environment" },
        });

        if (videoRef.current) {
          videoRef.current.srcObject = stream;
        }
      } catch  {
        setError("لا يمكن تشغيل الكاميرا — يرجى السماح بالأذن.");
      }
    }

    startCamera();

    return () => {
      if (stream) {
        stream.getTracks().forEach((t) => t.stop());
      }
    };
  }, []);

  const takePhoto = () => {
    if (!videoRef.current || !canvasRef.current) return;

    const video = videoRef.current;
    const canvas = canvasRef.current;

    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

    canvas.toBlob((blob) => {
      if (!blob) return;
      const file = new File([blob], "capture.jpg", { type: "image/jpeg" });
      onCapture(file);
    }, "image/jpeg");
  };

  return (
    <div
      className="
      fixed inset-0 bg-black/90 z-[999]
      flex flex-col items-center justify-center p-4
    "
    >
      {/* زر الإغلاق */}
      <button
        onClick={onClose}
        title="زر الاغلاق"
        className="absolute top-4 right-4 text-white p-2"
      >
        <X size={28} />
      </button>

      <h2 className="text-white mb-4 text-lg font-semibold">
        مسح عبر الكاميرا
      </h2>

      {error && (
        <p className="text-red-400 text-sm mb-3">{error}</p>
      )}

      {/* عرض الكاميرا */}
      <video
        ref={videoRef}
        autoPlay
        playsInline
        className="w-full max-w-md rounded-xl border border-slate-700"
      />

      {/* عنصر الرسم */}
      <canvas ref={canvasRef} className="hidden" />

      <Button
        className="mt-6 w-full max-w-md py-3 bg-white text-black"
        onClick={takePhoto}
      >
        التقاط الصورة
      </Button>
    </div>
  );
}
