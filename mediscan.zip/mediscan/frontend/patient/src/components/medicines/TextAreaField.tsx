"use client";

export default function TextAreaField({
  label,
  error,
  children,
}: {
  label: string;
  error?: string;
  children: React.ReactNode;
}) {
  return (
    <div className="space-y-1 text-sm">
      <label className="text-slate-700 dark:text-slate-200">{label}</label>
      {children}
      {error && (
        <p className="text-[11px] text-rose-500 pt-0.5">{error}</p>
      )}
    </div>
  );
}
