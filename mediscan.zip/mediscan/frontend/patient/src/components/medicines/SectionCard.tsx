"use client";

export default function SectionCard({
  title,
  children,
}: {
  title: string;
  children: React.ReactNode;
}) {
  return (
    <section className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 space-y-4 shadow-sm">
      <h2 className="text-base font-semibold text-slate-900 dark:text-slate-50">
        {title}
      </h2>
      {children}
    </section>
  );
}
