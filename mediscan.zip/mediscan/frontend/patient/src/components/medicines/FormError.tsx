"use client";

import React from "react";

export default function FormError({ children }: { children: React.ReactNode }) {
  return (
    <p className="text-[11px] text-rose-500 font-medium mt-1">
      {children}
    </p>
  );
}
