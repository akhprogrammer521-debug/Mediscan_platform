"use client";

import { Clock, X } from "lucide-react";
import Button from "@/components/ui/button";

export default function TimeBadge({
  time,
  onRemove,
}: {
  time: string;
  onRemove: () => void;
}) {
  return (
    <span className="inline-flex items-center gap-1 px-3 py-1.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 text-xs border border-slate-200 dark:border-slate-700">
      <Clock size={13} />
      {time}
      <Button
        type="button"
        onClick={onRemove}
        className="hover:text-rose-500"
      >
        <X size={13} />
      </Button>
    </span>
  );
}
