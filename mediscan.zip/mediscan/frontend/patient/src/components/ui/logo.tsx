"use client";

import Image from "next/image";

interface LogoProps {
  size?: "sm" | "md" | "lg";
}

export default function Logo({ size = "lg" }: LogoProps) {
  // الأحجام القياسية
  const sizes = {
    sm: 28,
    md: 36,
    lg: 52,
  };

  return (
    <div className="flex items-center gap-3 select-none">
      {/* صورة اللوغو */}
      <Image
        src="/logo.png"
        alt="MediScan Logo"
        width={sizes[size]}
        height={sizes[size]}
      />

      {/* النص */}
      <span
        className={`
          font-bold
          text-slate-800 dark:text-slate-100
          ${size === "lg" ? "text-3xl" : ""}
          ${size === "md" ? "text-xl" : ""}
          ${size === "sm" ? "text-base" : ""}
        `}
      >
        mediScan
      </span>
    </div>
  );
}
