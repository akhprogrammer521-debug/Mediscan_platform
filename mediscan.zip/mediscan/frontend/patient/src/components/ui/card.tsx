export default function Card({ children }: { children: React.ReactNode }) {
  return (
    <div
      className="
        bg-white dark:bg-slate-800 
        border border-slate-200 dark:border-slate-700 
        shadow-soft 
        rounded-2xl 
        p-4
      "
    >
      {children}
    </div>
  );
}
