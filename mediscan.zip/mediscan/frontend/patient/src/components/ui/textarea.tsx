interface TextareaProps {
  placeholder?: string;
  className?: string;
  value?: string;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  onChange?: (e: any) => void;
  rows?: number;
}

export default function Textarea({
  placeholder,
  className = "",
  value,
  onChange,
  rows = 4,
}: TextareaProps) {
  return (
    <textarea
      rows={rows}
      value={value}
      onChange={onChange}
      placeholder={placeholder}
      className={`
        w-full px-4 py-2 rounded-xl
        border border-slate-300 dark:border-slate-600
        bg-white dark:bg-slate-800
        focus:outline-none focus:ring-2 focus:ring-primary-500
        resize-none
        ${className}
      `}
    />
  );
}
