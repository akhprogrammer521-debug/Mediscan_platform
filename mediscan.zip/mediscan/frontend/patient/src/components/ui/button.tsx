import React from "react";

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  children: React.ReactNode;
}

export default function Button({
  children,
  className = "",
  ...props
}: ButtonProps) {
  return (
    <button
      {...props}
      className={`
        px-4 py-2 rounded-xl 
        bg-primary-600 text-white 
        hover:bg-primary-700 
        transition-colors
        dark:bg-primary-500 dark:hover:bg-primary-600
        ${className}
      `}
    >
      {children}
    </button>
  );
}
