"use client";

import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useState,
} from "react";

type ToastVariant = "success" | "error" | "info";

interface ToastState {
  id: number;
  message: string;
  variant: ToastVariant;
}

interface ToastContextValue {
  showToast: (message: string, variant?: ToastVariant) => void;
}

const ToastContext = createContext<ToastContextValue | undefined>(undefined);

export function ToastProvider({ children }: { children: React.ReactNode }) {
  const [toast, setToast] = useState<ToastState | null>(null);

  const showToast = useCallback((message: string, variant: ToastVariant = "info") => {
    const id = Date.now();
    setToast({ id, message, variant });
  }, []);

  useEffect(() => {
    if (!toast) return;
    const timer = setTimeout(() => setToast(null), 3000);
    return () => clearTimeout(timer);
  }, [toast]);

  return (
    <ToastContext.Provider value={{ showToast }}>
      {children}
      <ToastContainer toast={toast} />
    </ToastContext.Provider>
  );
}

export default function useToast() {
  const ctx = useContext(ToastContext);
  if (!ctx) {
    throw new Error("useToast must be used inside ToastProvider");
  }
  return ctx;
}

function ToastContainer({ toast }: { toast: ToastState | null }) {
  if (!toast) return null;

  let bg = "bg-slate-800";
  let border = "border-slate-600";

  if (toast.variant === "success") {
    bg = "bg-emerald-600";
    border = "border-emerald-400";
  } else if (toast.variant === "error") {
    bg = "bg-rose-600";
    border = "border-rose-400";
  }

  return (
    <div
      className="
        fixed inset-x-0 z-50 flex justify-center
        md:top-4 md:bottom-auto
        bottom-4
        pointer-events-none
      "
    >
      <div className="w-full max-w-sm mx-4 pointer-events-auto">
        <div
          className={`
            ${bg} ${border}
            text-white text-sm
            px-4 py-3 rounded-2xl
            shadow-xl border
            flex items-center justify-between gap-3
            animate-[fade-in_0.2s_ease-out]
          `}
        >
          <span>{toast.message}</span>
        </div>
      </div>
    </div>
  );
}
