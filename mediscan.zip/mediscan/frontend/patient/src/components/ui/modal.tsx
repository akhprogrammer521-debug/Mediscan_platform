"use client";

interface ModalProps {
  open: boolean;
  onClose: () => void;
  children: React.ReactNode;
}

export default function Modal({ open, onClose, children }: ModalProps) {
  if (!open) return null;

  return (
    <>
      <div
        className="fixed inset-0 bg-black bg-opacity-40 z-40"
        onClick={onClose}
      />
      <div
        className="
          fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2
          bg-white dark:bg-slate-800 rounded-2xl shadow-soft z-50 w-11/12 max-w-md p-6
        "
      >
        {children}
      </div>
    </>
  );
}
