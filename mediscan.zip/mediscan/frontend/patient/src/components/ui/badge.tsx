interface BadgeProps {
  children: React.ReactNode;
  variant?: "success" | "warning" | "danger" | "info";
}

const colors = {
  success: "bg-emerald-100 text-emerald-700 dark:bg-emerald-700 dark:text-white",
  warning: "bg-yellow-100 text-yellow-700 dark:bg-yellow-600 dark:text-white",
  danger: "bg-red-100 text-red-700 dark:bg-red-700 dark:text-white",
  info: "bg-blue-100 text-blue-700 dark:bg-blue-700 dark:text-white",
};

export default function Badge({ children, variant = "info" }: BadgeProps) {
  return (
    <span
      className={`px-3 py-1 rounded-full text-sm font-medium ${colors[variant]}`}
    >
      {children}
    </span>
  );
}
