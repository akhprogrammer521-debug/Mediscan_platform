import React from "react";

interface Option {
  label: string;
  value: string;
}

interface SelectProps {
  options: Option[];
  className?: string;
  onChange?: (e: React.ChangeEvent<HTMLSelectElement>) => void;
  value?: string;
  label?: string;
  id?: string;
}

export default function Select({
  options,
  className = "",
  onChange,
  value,
  label,
  id = "select-" + Math.random().toString(36).slice(2, 9),
}: SelectProps) {
  return (
    <div className="flex flex-col gap-1">
      {label && (
        <label
          htmlFor={id}
          className="text-sm text-slate-600 dark:text-slate-300"
        >
          {label}
        </label>
      )}

      <select
        id={id}
        aria-label={label}
        value={value}
        onChange={onChange}
        className={`
          w-full px-4 py-2 rounded-xl
          border border-slate-300 dark:border-slate-600
          bg-white dark:bg-slate-800
          focus:outline-none focus:ring-2 focus:ring-primary-500
          ${className}
        `}
      >
        {options.map((opt) => (
          <option key={opt.value} value={opt.value}>
            {opt.label}
          </option>
        ))}
      </select>
    </div>
  );
}
