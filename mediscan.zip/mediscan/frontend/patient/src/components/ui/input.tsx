import React from "react";

interface InputProps {
  type?: string;
  placeholder?: string;
  className?: string;
  value?: string | number;
  onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
}

export default function Input({
  type = "text",
  placeholder,
  className = "",
  value,
  onChange,
}: InputProps) {
  return (
    <input
      type={type}
      value={value}
      onChange={onChange}
      placeholder={placeholder}
      className={`
        w-full px-4 py-2 rounded-xl
        border border-slate-300 dark:border-slate-600
        bg-white dark:bg-slate-800
        focus:outline-none focus:ring-2 focus:ring-primary-500
        ${className}
      `}
    />
  );
}
