// src/services/ocrApi.ts

export interface ScanAnalysis {
  drugName?: string;
  dosage?: string;
  frequency?: string;
  language?: string;
}

export interface ScanDrugResponse {
  scan: {
    id: number;
    text: string;
    language: string;
  };
  drug: {
    id: number;
    name: string;
  } | null;
  analysis: ScanAnalysis;
  text: string;
}

export async function scanDrug(
  image: File
): Promise<ScanDrugResponse> {
  const formData = new FormData();
  formData.append("image", image);

  const res = await fetch(
    `${process.env.NEXT_PUBLIC_API_URL}/patient/ocr/scan`,
    {
      method: "POST",
      credentials: "include",
      body: formData,
    }
  );

  if (!res.ok) {
    throw new Error("فشل تحليل الدواء");
  }

  return res.json();
}
