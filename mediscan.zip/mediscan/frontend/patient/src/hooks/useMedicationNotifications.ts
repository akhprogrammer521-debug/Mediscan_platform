import { useEffect } from "react";

interface Schedule {
  time: string;
  takenToday: boolean;
}

export function useMedicationNotifications(schedules: Schedule[]) {
  useEffect(() => {
    const now = new Date();

    schedules.forEach((s) => {
      if (s.takenToday) return;

      const [h, m] = s.time.split(":").map(Number);
      const doseTime = new Date();
      doseTime.setHours(h, m, 0, 0);

      if (doseTime > now) {
        const delay = doseTime.getTime() - now.getTime();
        setTimeout(() => {
          alert("⏰ حان وقت تناول جرعتك");
        }, delay);
      }
    });
  }, [schedules]);
}