// src/utils/medicineValidation.ts
import * as Yup from "yup";

export const MedicineSchema = Yup.object().shape({
  name: Yup.string()
    .required("اسم الدواء مطلوب")
    .min(3, "اسم الدواء يجب أن يكون أطول من 3 أحرف"),
  dosage: Yup.string()
    .required("الجرعة وطريقة الاستخدام مطلوبة")
    .min(5, "يرجى كتابة جرعة مفصلة أكثر"),
  type: Yup.string().oneOf(["chronic", "temporary", "asNeeded"]),
  notes: Yup.string().optional(),
  timesPerDay: Yup.number()
    .required()
    .min(1, "يجب تحديد مرة واحدة على الأقل")
    .max(12, "أقصى عدد مسموح 12 مرة يومياً"),
  scheduleTimes: Yup.array()
    .of(Yup.string())
    .min(1, "يجب إضافة وقت واحد على الأقل"),
});
