/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: 'class',

  content: [
    "./src/app/**/*.{js,ts,jsx,tsx}",
    "./src/components/**/*.{js,ts,jsx,tsx}",
  ],

  theme: {
    extend: {
      colors: {
        primary: {
          500: "#3B82F6",
          600: "#2563EB",
          700: "#1D4ED8",
        },
        secondary: {
          500: "#10B981",
          600: "#059669",
        },

        // Neutral Palette
        lightBg: "#F8FAFC",
        lightText: "#1E293B",
        darkBg: "#0F172A",
        darkCard: "#1E293B",
      },

      borderRadius: {
        'xl': '1rem',
        '2xl': '1.25rem',  // حسب اختيارك للكروت
      },

      boxShadow: {
        soft: "0 2px 8px rgba(0,0,0,0.06)",
      },

      fontFamily: {
        inter: ["var(--font-inter)", "sans-serif"],
      },
    },
  },

  plugins: [],
};
